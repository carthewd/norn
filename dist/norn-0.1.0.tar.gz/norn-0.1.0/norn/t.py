import test
import events

t = test.CWEventTest()

#t.load_pattern('/tmp/pat')
e = events.CloudWatchEvents()

t.trigger_lambda('norntest', e.ec2[0])
#t.test_pattern(e.ec2[0])
